const express = require('express')

const router = express.Router()

const mongoose = require('mongoose')
const User = mongoose.model("User")



router.post('/signup',(req,res)=> {
   const {name,email,phone,message} = req.body
   if(!name || !email || !phone || !message) {
      return res.status(422).json({error:"please fill out all the fields"})
   }
   User.findOne({email:email})
   .then((savedUser)=>{
       if(savedUser){
        return res.status(422).json({error:"email already sent"})
       }
       const user = new User({
           email,
           name,
           phone,
           message
       })

       user.save()
       .then(user=>{
           res.json({message:"saved sent messaged"})
       })
       .catch(err=> {
           console.log(err)
       })
   })
   .catch(err=> {
       console.log(err)
   })
})


router.post('/signin')


module.exports = router