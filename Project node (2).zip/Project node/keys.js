module.exports={
  MONGOURI:"mongodb+srv://cristian:GRKoBzrGOQbuOs98@cluster0-xl13o.mongodb.net/Test?retryWrites=true&w=majority"
}